# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    "name": "Mexican Invoicing 4.0",
    "summary": """
    Module create new invoice xml version 4.0 SAT.
    Add catalog of new keys and values of SAT""",
    "version": "16.0.0.0.1",
    "category": "Accounting",
    "author": "QUADIT",
    'website': 'https://www.quadit.mx',
    "license": "OPL-1",
    "depends": [
        'l10n_mx',
        'account',
        'sale',
    ],
    "demo": [],
    "data": [
        'data/clave.prod.serv.csv',
        'data/clave.prod.uom.csv',
        'data/res.fiscal.regime.csv',
        'data/res.forma.pago.csv',
        'data/res.met.pago.csv',
        'data/res.uso.cfdi.csv',
        'report/report_invoice.xml',
        'report/invoice_view.xml',
        'security/groups.xml',
        'security/ir.model.access.csv',
        'views/account_journal_views.xml',
        'views/account_move_views.xml',
        'views/account_tax_views.xml',
        'views/clave_prod_serv_views.xml',
        'views/clave_prod_uom_views.xml',
        'views/ir_sequence_views.xml',
        'views/params_pac_view.xml',
        'views/product_category_views.xml',
        'views/product_product_views.xml',
        'views/product_template_views.xml',
        'views/res_company_facturae_certificate_views.xml',
        'views/res_company_views.xml',
        'views/res_fiscal_regime_views.xml',
        'views/res_forma_pago_views.xml',
        'views/res_partner_view.xml',
        'views/res_uso_cfdi_views.xml',
        'views/sale_order_views.xml',
        'views/uom_uom_views.xml',
        'views/menuitem.xml',
    ],
    "external_dependencies": {
        "python": [
            "OpenSSL",
            "xmltodict",
            "m2crypto",
        ],
        "bin": [
            "xsltproc",
            "xmlstarlet",
            "swig",
        ],
    },
    'assets': {
        'web.report_assets_pdf': [
            'l10n_mx_facturae_40/static/src/scss/**/*',
        ],
        'web.report_assets_common': [
            'l10n_mx_facturae_40/static/src/scss/**/*',
        ],
    },
    "installable": True,
}
