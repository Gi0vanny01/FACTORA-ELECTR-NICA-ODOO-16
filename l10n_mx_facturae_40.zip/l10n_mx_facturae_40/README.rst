# Mexican EDI for CE

# You needs to install xsltproc, xmlstarlet
# with the next commands:

# apt-get update
# apt-get install xsltproc
# apt-get install xmlstarlet

Before install m2crypto run
# apt-get install build-essential libssl-dev swig python3-dev

After
# pip3 install m2crypto
# pip3 install xmltodict
