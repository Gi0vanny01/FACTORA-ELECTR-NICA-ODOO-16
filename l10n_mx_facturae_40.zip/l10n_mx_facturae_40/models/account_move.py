# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
import logging

_logger = logging.getLogger(__name__)

class AccountMove(models.Model):
    _inherit = "account.move"

    tax_line_ids = fields.One2many('account.tax', 'type_tax_use', string='Tax Lines', copy=False, compute="_get_tax_lines")
    
    @api.depends('invoice_line_ids')
    def _get_tax_lines(self):
        for record in self:
            taxs = []
            for line in record.invoice_line_ids:
                if line.tax_ids:
                    for l in line.tax_ids:
                        taxs.append(l.id)
            if taxs:
                taxs = list(set(taxs))
            record.tax_line_ids = taxs

    def print_info(self, info):
        _logger.info('====>print_info {0} <===='.format(info))