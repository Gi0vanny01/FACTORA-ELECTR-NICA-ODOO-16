# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_journal
from . import account_move_line
from . import account_move
from . import account_tax
from . import clave_prod_serv
from . import clave_prod_uom
from . import facturae_lib
from . import invoice
from . import ir_attachment
from . import ir_sequence
# from . import mail_template
from . import params_pac
from . import product_category
from . import product_template
from . import res_company
from . import res_fiscal_regime
from . import res_forma_pago
from . import res_met_pago
from . import res_partner
from . import res_uso_cfdi
from . import sale_order_line
from . import sale_order
from . import uom_uom