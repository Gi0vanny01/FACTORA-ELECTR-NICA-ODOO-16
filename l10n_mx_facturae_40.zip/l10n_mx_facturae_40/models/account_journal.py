# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    address_invoice_company_id = fields.Many2one('res.partner', 'Direccion de Factura')
    company2_id = fields.Many2one("res.company", 'Compañia Emisora')
    fiscal = fields.Boolean('Diario SAT')