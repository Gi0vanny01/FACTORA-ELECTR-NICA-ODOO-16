# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    claveserv_id = fields.Many2one('clave.prod.serv', 'Clave servicio')

    @api.onchange('product_id')
    def _inverse_product_id(self):
        super()._inverse_product_id()
        self.claveserv_id = self.product_id.claveserv_id.id or \
            self.product_id.product_tmpl_id.claveserv_id.id or \
            self.product_id.categ_id.claveserv_id.id or \
            False