# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class AccountTax(models.Model):
    _inherit = 'account.tax'

    code_sat = fields.Selection([
        ('001', 'ISR 001'),
        ('002', 'IVA 002'),
        ('003', 'IEPS 003'),
    ])