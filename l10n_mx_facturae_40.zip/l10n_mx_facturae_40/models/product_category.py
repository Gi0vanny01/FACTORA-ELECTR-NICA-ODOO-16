# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class ProductCategory(models.Model):
    _inherit = 'product.category'

    claveserv_id = fields.Many2one('clave.prod.serv', 'ClaveProdServ SAT')