# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResFiscalRegime(models.Model):
    _name = 'res.fiscal.regime'
    _description = 'Régimen fiscal'
    _sql_constraints = [('code_unique', 'UNIQUE (code)', 'El codigo debe ser unico')]

    code = fields.Char(size=3, required=True)
    name = fields.Char(size=256)

    @api.depends('code', 'name')
    def name_get(self):
        result = []
        for record in self:
            name = '%s - %s' % (record.code, record.name)
            result.append((record.id, name))
        return result