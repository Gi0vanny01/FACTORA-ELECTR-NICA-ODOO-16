# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResUsoCFDI(models.Model):
    """Object use to save the catalog to Use of CFDIs"""
    _name = 'res.uso.cfdi'
    _description = 'Uso CFDI'
    _sql_constraints = [('name_unique', 'UNIQUE (name)', 'La clave debe ser unica')]

    name = fields.Char('Codigo', size=3, required=True)
    description = fields.Char(size=256)
    fisica = fields.Boolean()
    moral = fields.Boolean()
    date = fields.Date('Fecha inicio de vigencia')
    date_due = fields.Date('Fecha fin de vigencia')

    @api.depends('name', 'description')
    def name_get(self):
        result = []
        for pay in self:
            name = pay.name + ' ' + pay.description
            result.append((pay.id, name))
        return result

    @api.model
    def name_search(self, name, args=None, operator='ilike', limit=100):
        args = args or []
        recs = self.browse()
        if name:
            recs = self.search([('description', operator, name)] + args, limit=limit)
        if not recs:
            recs = self.search([('name', operator, name)] + args, limit=limit)
        return recs.name_get()