# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResMetPago(models.Model):
    """Object use to save the catalog to payment methods"""
    _name = 'res.met.pago'
    _description = 'Metodo de pago'
    _sql_constraints = [('name_unique', 'UNIQUE (name)', 'El codigo debe ser unica')]

    name = fields.Char('Codigo', size=3, required=True)
    description = fields.Char(size=256)

    @api.depends('name', 'description')
    def name_get(self):
        result = []
        for pay in self:
            name = '%s %s' % (pay.name, pay.description)
            result.append((pay.id, name))
        return result