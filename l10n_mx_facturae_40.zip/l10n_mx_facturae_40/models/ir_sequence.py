# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class Sequence(models.Model):
    _inherit = 'ir.sequence'

    serie = fields.Char('Serie de Folios', size=12, required=False)