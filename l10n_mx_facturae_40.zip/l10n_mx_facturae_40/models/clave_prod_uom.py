# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ClaveProdUom(models.Model):
    """Object to hold the SAT catalog to UoMs"""
    _name = 'clave.prod.uom'
    _description = 'Clave UdM'
    _rec_name = 'clave'
    _sql_constraints = [('clave_unique', 'UNIQUE (clave)', 'La clave debe ser unica')]

    clave = fields.Char(size=3, required=True)
    name = fields.Char(size=128, required=True)
    simbol = fields.Char(size=32)
    description = fields.Text()

    @api.depends('clave', 'name')
    def name_get(self):
        result = []
        for pay in self:
            name = '%s %s' % (pay.clave, pay.name)
            result.append((pay.id, name))
        return result

    @api.model
    def name_search(self, name, args=None, operator='ilike', limit=100):
        args = args or []
        recs = self.browse()
        if name:
            recs = self.search([('name', operator, name)] + args, limit=limit)
        if not recs:
            recs = self.search([('name', operator, name)] + args, limit=limit)
        return recs.name_get()