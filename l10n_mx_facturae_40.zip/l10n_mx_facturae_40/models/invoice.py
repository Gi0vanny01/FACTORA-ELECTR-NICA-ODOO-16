# -*- coding: utf-8 -*-
# Copyright 2022 - QUADIT, SA DE CV(https://www.quadit.mx)
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

import base64
import os
import tempfile
import time
from datetime import datetime, timedelta
import json
import string
import re
import random
from pytz import timezone
import pytz
import requests
import logging
import xmltodict

from zeep import Client
from zeep.transports import Transport
from json.decoder import JSONDecodeError
from lxml import etree, objectify
from jinja2 import Environment, FileSystemLoader, StrictUndefined
from odoo import api, fields, models, _, tools
from odoo.exceptions import ValidationError, UserError

_logger = logging.getLogger(__name__)

def diff_month(d1, d2):
    return (d1.year - d2.year) * 12 + d1.month - d2.month
    
def conv_ascii(text):
    """Convierte vocales accentuadas, ñ y ç a sus caracteres equivalentes ASCII
    """
    old_chars = [
        'á', 'é', 'í', 'ó', 'ú', 'à', 'è', 'ì', 'ò', 'ù', 'ä', 'ë', 'ï', 'ö',
        'ü', 'â', 'ê', 'î', 'ô', 'û', 'Á', 'É', 'Í', 'Ó', 'Ú', 'À', 'È', 'Ì',
        'Ò', 'Ù', 'Ä', 'Ë', 'Ï', 'Ö', 'Ü', 'Â', 'Ê', 'Î', 'Ô', 'Û', 'ñ', 'Ñ',
        'ç', 'Ç', 'ª', 'º', '°', ' ', 'Ã', '"']
    new_chars = [
        'a', 'e', 'i', 'o', 'u', 'a', 'e', 'i', 'o', 'u', 'a', 'e', 'i', 'o',
        'u', 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U', 'A', 'E', 'I',
        'O', 'U', 'A', 'E', 'I', 'O', 'U', 'A', 'E', 'I', 'O', 'U', 'n', 'N',
        'c', 'C', 'a', 'o', 'o', ' ', 'A', "'"]
    for old, new in zip(old_chars, new_chars):
        try:
            text = text.replace(unicode(old, 'UTF-8'), new)
        except Exception:
            try:
                text = text.replace(old, new)
            except Exception:
                raise ValidationError(_(
                    'No se pudo re-codificar la cadena [%s] en la letra [%s]') % (text, old))  # noqa
    return text


class AccountMove(models.Model):
    _inherit = 'account.move'

    carta_porte = fields.Boolean("Carta porte")

    def _get_date_invoice_tz_33(self):
        for invoice in self.filtered(lambda i: i.move_type in (
                'out_invoice', 'out_refund')):
            dt_tz = fields.Datetime.context_timestamp(
                self.with_context(tz=self.env.user.tz),
                fields.Datetime.from_string(fields.Datetime.now()))
            invoice.date_invoice_tz_33 = fields.Datetime.to_string(dt_tz)
 
    def _get_address_issued_invoice(self):
        a = self.journal_id.address_invoice_company_id.id or False
        address_invoice = a
        self.address_issued_id = address_invoice

    def _get_company_emitter_invoice(self):
        for invoice in self:
            company_invoice = invoice.journal_id.company2_id and \
                invoice.journal_id.company2_id.id or invoice.company_id and \
                invoice.company_id.id or False
            invoice.company_emitter_id = company_invoice

    sign = fields.Boolean('Timbrada', copy=False)
    fiscal = fields.Boolean(related='journal_id.fiscal', string='CFDI')
    cfdi_folio_fiscal = fields.Char('Folio Fiscal(UUID)', size=256, copy=False)
    forma_pago_id = fields.Many2one('res.forma.pago', 'Forma de pago')
    met_pago_id = fields.Many2one('res.met.pago', 'Metodo de pago')
    uso_cfdi_id = fields.Many2one('res.uso.cfdi', 'Uso CFDI')
    parent_invoice_rel_id = fields.Many2one('account.move')
    invoice_rel_ids = fields.One2many('account.move', 'parent_invoice_rel_id', string='CFDI relacionado', domain=[('sign', '=', True)])
    type_invoice_rel = fields.Selection([
        ('01', '01 - Nota de crédito de los documentos relacionados'),
        ('02', '02 - Nota de débito de los documentos relacionados'),
        ('03', '03 - Devolución de mercancía sobre facturas o traslados previos'),
        ('04', '04 - Sustitución de los CFDI previos'),
        ('05', '05 - Traslados de mercancias facturados previamente'),
        ('06', '06 - Factura generada por los traslados previos'),
        ('07', '07 - CFDI por aplicación de anticipo'),
    ], 'Tipo de relación')
    cfdi_fecha_cancelacion = fields.Datetime('CFDI Fecha cancelacion')
    cfdi_cadena_original = fields.Text('CFD-I Original String')
    cfdi_sello = fields.Text('CFD-I Sello', help='Sign assigned by the SAT')
    cfdi_no_certificado = fields.Char(
        'CFD-I Certificado', size=32, help='Serial Number of the Certificate')
    cfdi_cadena_original = fields.Text(
        'CFD-I Cadena Original',
        help='Original String used in the electronic invoice')
    cfdi_fecha_timbrado = fields.Datetime(
        'CFD-I Fecha Timbrado',
        help='Date when is stamped the electronic invoice')
    no_certificado = fields.Text(
        'Certificate', size=64, help='Certificate used in the invoice')
    sello = fields.Text('Stamp', size=512, help='Digital Stamp')
    cfdi_cbb = fields.Binary('CFD-I CBB')
    cfdi_name = fields.Char(help='Used to save the CFDI name')
    sat_status = fields.Char("Estado en el SAT", help='Return the document status in the SAT', default='Sin Consultar.')
    address_issued_id = fields.Many2one(
        compute=_get_address_issued_invoice,
        comodel_name='res.partner', string='Address Issued Invoice',
        help='This address will be used as address that issued for electronic '
        'invoice')
    company_emitter_id = fields.Many2one(
        compute=_get_company_emitter_invoice,
        comodel_name='res.company',
        string='Company Emitter Invoice',
        help='This company will be used as emitter company in the electronic '
        'invoice')
    invoice_datetime_33 = fields.Datetime(
        'Date Electronic Invoiced ',
        states={'open': [('readonly', True)], 'close': [('readonly', True)]},
        help="Keep empty to use the current date", copy=False)
    date_invoice_tz_33 = fields.Datetime(
        compute=_get_date_invoice_tz_33, method=True,
        string='Date Invoiced with TZ',
        help='Date of Invoice with Time Zone')
    ttype_cancel = fields.Selection([
        ('01', '01|Comprobante emitido con errores con relación.'),
        ('02', '02|Comprobante emitido con errores sin relación.'),
        ('03', '03|No se llevó a cabo la operación.'),
        ('04', '04|Operación nominativa relacionada en una factura global.'),
    ], 'Tipo cancelacion', default=False, copy=False,
        help='En el caso de que el motivo de cancelación sea "01 - Comprobante emitido con errores con relación" se deberá especificar el UUID del comprobante que sustituye al comprobante a cancelar.')
    uuid_replace_cancel = fields.Char("UUID a sustituir")
    cfdi_cancelado = fields.Boolean("CFDI cancelado")

    def log_error(self, message):
        self.ensure_one()
        self.message_post(body=_('Error: %s') % message)

    @api.model
    def create(self, vals):
        onchanges = {
            '_onchange_partner_id': ['met_pago_id', 'forma_pago_id', 'uso_cfdi_id'],
        }
        for onchange_method, changed_fields in onchanges.items():
            if any(f not in vals for f in changed_fields):
                invoice = self.new(vals)
                getattr(invoice, onchange_method)()
                for field in changed_fields:
                    if field not in vals and invoice[field]:
                        vals[field] = invoice._fields[
                            field].convert_to_write(invoice[field], invoice)
        return super().create(vals)

    def encrypt_key(self, rsa, password):
        rsa_encrypt = rsa.as_pem("des_ede3_cbc", lambda x: password)
        return rsa_encrypt

    def button_cancel(self):
        for payment in self:
            att = payment.retrive_attachment()
            if not att:
                return super().button_cancel()
            status = payment.valida_xml(att.datas).get('acuse')
            if status and status.Estado == 'Cancelado':
                return super().button_cancel()
            if status and status.Estado != 'Cancelado':
                self.action_cancel_cfdi()
            res = super().button_cancel()
            self.env['ir.attachment'].search([
                ('res_id', 'in', self.filtered(lambda i: not i.sign).ids),
                ('res_model', '=', 'account.move')]).unlink()
            return res

    def retry_cancel(self):
        self.action_cancel_cfdi()

    def action_cancel_cfdi(self):
        pac_params_obj = self.env['params.pac']
        for inv in self.filtered('sign'):
            if not inv.ttype_cancel:
                raise UserError(_('No se ha configurado el tipo de cancelación'))
            if not inv.company_id.certificate_id:
                inv.message_post(body=_('No tienes definido certificado para esta compañia!'))
                continue
            pac_params = pac_params_obj.search([
                ('method_type', '=', 'cancelar'),
                ('company_id', '=', inv.company_emitter_id.id),
            ], limit=1)
            if not pac_params:
                inv.message_post(body=_(
                    'No tienes parametros del PAC configurados para '
                    'cancelar'))
                continue
            if pac_params.pac == 'finkok':
                inv.mx_cancel_finkok(pac_params)
            elif pac_params.pac == 'sw':
                inv.mx_cancel_sw(pac_params)
            elif pac_params.pac == 'sf':
                inv.mx_cancel_sf(pac_params)

    def mx_cancel_finkok(self, pac_params):
        uuid = self.cfdi_folio_fiscal
        company = self.company_id
        certificate_id = company.certificate_id
        cer_pem = certificate_id.get_pem_cer(certificate_id.cer_file)
        key_pem = certificate_id.get_pem_key(certificate_id.key_file, certificate_id.password)
        try:
            transport = Transport(timeout=20)
            client = Client(pac_params.url_webservice, transport=transport)
            uuid_type = client.get_type('ns0:UUID')()
            uuid_type.UUID = uuid
            uuid_type.Motivo = self.ttype_cancel
            if self.ttype_cancel == '01':
                uuid_type.FolioSustitucion = self.uuid_replace_cancel
            docs_list = client.get_type('ns0:UUIDS')(uuid_type)
            response = client.service.cancel(
                docs_list,
                pac_params.user,
                pac_params.password,
                company.vat,
                cer_pem,
                key_pem,
            )
        except Exception as e:
            self.message_post(body=_("The Finkok service failed to cancel with the following error: %s", str(e)))            
            return None

        if not getattr(response, 'Folios', None):
            code = getattr(response, 'CodEstatus', None)
            msg = _("Cancelling got an error") if code else _('A delay of 2 hours has to be respected before to cancel')
        else:
            code = getattr(response.Folios.Folio[0], 'EstatusUUID', None)
            cancelled = code in ('201', '202')  # cancelled or previously cancelled
            # no show code and response message if cancel was success
            code = '' if cancelled else code
            msg = '' if cancelled else _('A delay of 2 hours has to be respected before to cancel')
        self.message_post(body=_('%s %s' % (code, msg)))

    def mx_cancel_sf(self, pac_params):
        msg = ''
        folio_cancel = ''
        pac_usr = pac_params.user
        pac_pwd = pac_params.password
        url = pac_params.url_webservice
        certificate_id = self.company_id.certificate_id
        cer_pem = certificate_id.get_pem_cer(certificate_id.cer_file)
        key_pem = certificate_id.get_pem_key(
            certificate_id.key_file, certificate_id.password)
        xml = self.cfdi_etree()
        tfd_node = self._get_stamp_data(xml)
        folio_cancel = tfd_node.get('UUID') + "|" + self.ttype_cancel + "|"
        uuids = [folio_cancel]
        try:
            transport = Transport(timeout=20)
            client = Client(url, transport=transport)
            result = client.service.cancelar(
                pac_usr, pac_pwd, uuids, cer_pem, key_pem, certificate_id.password)
        except Exception as e:
            self.message_post(body=_(
                'Revisa tu conexion a internet y los datos del PAC'))
            return False
        res = result.resultados
        code = getattr(res[0], 'statusUUID', None) if res else getattr(
            response, 'status', None)
        cancelled = code in ('201', '202')
        msg = '' if cancelled else getattr(
            res[0] if res else response, 'mensaje', None)
        code = '' if cancelled else code
        if cancelled:
            self.cfdi_fecha_cancelacion = time.strftime('%Y-%m-%d %H:%M:%S')
            self.cfdi_cancelado = True
            self.message_post(
                body=_('\n- El proceso de cancelación se ha completado correctamente.'))
        else:
            self.message_post(body=_('Mensaje %s\nCode: %s') % (msg, code))

    def cfdi_etree(self):
        fname = '%s_%s.xml' % (self.company_emitter_id.partner_id.vat,
                               self.name)
        att_xml_id = self.env['ir.attachment'].search([
            ('name', '=', fname),
            ('res_model', '=', 'account.move'),
            ('res_id', '=', self.id),
        ], limit=1)
        if not len(att_xml_id) >= 1:
            return False
        return objectify.fromstring(base64.b64decode(att_xml_id.datas))

    def retrive_attachment(self):
        self.ensure_one()
        return self.env['ir.attachment'].search([
            ('name', '=', self.cfdi_name),
            ('res_model', '=', 'account.move'),
            ('res_id', '=', self.id)], limit=1)

    def sign_cfdi(self):
        for invoice in self:
            attachment_xml_id = invoice.retrive_attachment()
            if not attachment_xml_id:
                invoice.create_cfdi()
                attachment_xml_id = invoice.retrive_attachment()
                if not attachment_xml_id:
                    invoice.message_post(body=_(
                        'No se encuentra XML para timbrar !'))
                    continue
            pac_params_ids = self.env['params.pac'].search([
                ('method_type', 'ilike', 'firmar'), (
                    'company_id', '=', invoice.company_emitter_id.id)], limit=1)
            if not pac_params_ids:
                invoice.message_post(body=_(
                    'No tienes parametros del PAC configurados'))
                continue
            if pac_params_ids.pac == 'finkok':
                invoice.mx_stamp_finkok(pac_params_ids, attachment_xml_id)
            elif pac_params_ids.pac == 'sw':
                invoice.mx_stamp_sw(pac_params_ids, attachment_xml_id)
            elif pac_params_ids.pac == 'sf':
                invoice.mx_stamp_sf(pac_params_ids, attachment_xml_id)
        return True

    def mx_stamp_finkok(self, pac_params_ids, attachment):
        self.ensure_one()
        pac_usr = pac_params_ids.user
        pac_pwd = pac_params_ids.password
        pac_url = pac_params_ids.url_webservice
        transport = Transport(timeout=20)
        client = Client(pac_url, transport=transport)
        xml_datas = attachment.datas
        xml =  base64.b64decode(xml_datas)
        resultado = None
        try:
            resultado = client.service.stamp(xml, pac_usr, pac_pwd)
        except Exception as e:
            self.log_error(str(e))
        code = 0
        msg = None

        if resultado and resultado.Incidencias and not resultado.xml:
            code = getattr(
                resultado.Incidencias['Incidencia'][0], 'CodigoError', None)
            msg = getattr(
                resultado.Incidencias['Incidencia'][0],
                'MensajeIncidencia' if code !=
                '301' else 'ExtraInfo', None)
            self.message_post(body=_(' %s - %s ') % (code, msg))
            return False

        if resultado and resultado.xml:
            cfdi_xml = resultado.xml.encode(
                'ascii', 'xmlcharrefreplace') or ''
            attachment.write({
                'mimetype': 'application/xml',
                'type': 'binary',
                'datas': base64.encodebytes(cfdi_xml)})
            data_cfdi = {
                'sign': True,
                'cfdi_folio_fiscal': resultado['UUID'],
                'cfdi_fecha_timbrado': resultado['Fecha'].replace('T', ' '),
                'cfdi_no_certificado': resultado['NoCertificadoSAT'],
                'cfdi_sello': resultado['SatSeal'],
            }
            self.write(data_cfdi)
            self.cfdi_cadena_original = self._create_original_str()
            return True

    def mx_stamp_sf(self, pac_params_ids, attachment):
        self.ensure_one()
        pac_usr = pac_params_ids.user
        pac_pwd = pac_params_ids.password
        pac_url = pac_params_ids.url_webservice
        xml = attachment.datas
        
        transport = Transport(timeout=20)
        client = Client(pac_url, transport=transport)
        response = client.service.timbrar(pac_usr, pac_pwd, base64.b64decode(xml), False)
        
        res = response.resultados
        code = getattr(res[0] if res else response, 'status', None)
        msg = getattr(res[0] if res else response, 'mensaje', None)
        self.message_post(body=_(' %s - %s ') % (code, msg))

        xml_signed = getattr(res[0] if res else response, 'cfdiTimbrado', None)
        if xml_signed:
            cfdi_xml = base64.b64encode(xml_signed)
            attachment.write({'datas': cfdi_xml, 'mimetype': 'application/xml'})
            data_cfdi = {
                'sign': True,
                'cfdi_folio_fiscal': res[0]['uuid'],
                'cfdi_fecha_timbrado': res[0]['fechaTimbrado'].date(),
                'cfdi_no_certificado': res[0]['certificadoSAT'],
                'cfdi_sello': res[0]['selloSAT'],
                'cfdi_cadena_original': res[0]['cadenaOriginal'],
                'sat_status': "No sincronizado",
                
            }
            self.write(data_cfdi)
            return True

    @api.model
    def _l10n_mx_edi_get_serie_and_folio(self, move):
        name_numbers = list(re.finditer('\d+', move.name))
        serie_number = move.name[:name_numbers[-1].start()]
        folio_number = name_numbers[-1].group().lstrip('0')
        return {
            'serie_number': serie_number,
            'folio_number': folio_number,
        }

    @staticmethod
    def _l10n_mx_edi_sw_token(pac_info):
        """Get token for SW PAC
        """
        if pac_info.password and not pac_info.user:
            # token is configured directly instead of user/password
            token = pac_info.password.strip()
            return token, None
        try:
            headers = {
                'user': pac_info.user,
                'password': pac_info.password,
                'Cache-Control': "no-cache"
            }
            response = requests.post(pac_info.login_url, headers=headers)
            response.raise_for_status()
            response_json = response.json()
            return response_json['data']['token'], None
        except (requests.exceptions.RequestException, KeyError, TypeError) as req_e:
            return None, str(req_e)

    @staticmethod
    def _l10n_mx_edi_sw_post(url, headers, payload=None):
        """Send requests.post to PAC SW
        return dict using keys 'status' and 'message'
          e.g. if is success
            {'status': 'success', 'data': {'cfdi': XML}}
          e.g. if is not success
            {'status': 'error', 'message': error, 'messageDetail': error}
        """
        try:
            response = requests.post(url, data=payload, headers=headers,
                                     verify=True, timeout=20)
        except requests.exceptions.RequestException as req_e:
            return {'status': 'error', 'message': str(req_e)}
        msg = ""
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as res_e:
            msg = str(res_e)
        try:
            response_json = response.json()
        except JSONDecodeError:
            # If it is not possible get json then
            # use response exception message
            return {'status': 'error', 'message': msg}
        if (response_json['status'] == 'error' and
                response_json['message'].startswith('307')):
            # XML signed previously
            cfdi = base64.encodebytes(
                response_json['message'].encode('UTF-8'))
            cfdi = cfdi.decode('UTF-8')
            response_json['data'] = {'cfdi': cfdi}
            # We do not need an error message if XML signed was
            # retrieved then cleaning them
            response_json.update({
                'message': None,
                'messageDetail': None,
                'status': 'success',
            })
        return response_json

    @staticmethod
    def _l10n_mx_edi_sw_boundary():
        lst = [random.choice(string.ascii_letters + string.digits)
               for n in range(30)]
        boundary = "".join(lst)
        return boundary

    def mx_stamp_sw(self, pac_info, attachment):
        token, req_e = self._l10n_mx_edi_sw_token(pac_info)
        if not token:
            self.message_post(body=_("Token could not be obtained %s") % req_e)
            return
        url = pac_info.url_webservice
        for rec in self:
            xml = attachment.datas.decode('UTF-8')
            boundary = self._l10n_mx_edi_sw_boundary()
            payload = """--%(boundary)s
Content-Type: text/xml
Content-Transfer-Encoding: binary
Content-Disposition: form-data; name="xml"; filename="xml"

%(xml)s
--%(boundary)s--
""" % {'boundary': boundary, 'xml': xml}
            headers = {
                'Authorization': "bearer " + token,
                'Content-Type': ('multipart/form-data; '
                                 'boundary="%s"') % boundary,
            }
            payload = payload.replace('\n', '\r\n').encode('UTF-8')
            response_json = self._l10n_mx_edi_sw_post(
                url, headers, payload=payload)
            code = response_json.get('message')
            msg = response_json.get('messageDetail')
            try:
                xml_signed = response_json['data']['cfdi']
            except (KeyError, TypeError):
                xml_signed = None
            if not xml_signed:
                self.message_post(body=_(' %s - %s ') % (code, msg))
                return False

            cfdi_xml = xml_signed.encode('utf-8')
            attachment.write({'datas': cfdi_xml, 'mimetype':'application/xml'})
            tfd = self._get_stamp_data(
                objectify.fromstring(base64.b64decode(xml_signed)))
            data_cfdi = {
                'sign': True,
                'cfdi_folio_fiscal': tfd.get('UUID'),
                'cfdi_fecha_timbrado': tfd.get('FechaTimbrado').replace('T', ' '),
                'cfdi_no_certificado': tfd.get('NoCertificadoSAT'),
                'cfdi_sello': tfd.get('SelloSAT'),
            }
            self.write(data_cfdi)
            self.cfdi_cadena_original = self._create_original_str()
            return True

    def mx_cancel_sw(self, pac_info):
        token, req_e = self._l10n_mx_edi_sw_token(pac_info)
        if not token:
            self.message_post(body=_("Token could not be obtained %s") % req_e)
            return
        url = pac_info.url_webservice
        headers = {
            'Authorization': "bearer " + token,
            'Content-Type': "application/json"
        }
        xml = self.cfdi_etree()
        tfd_node = self._get_stamp_data(xml)
        certificate = self.company_id.certificate_id
        cer_pem = base64.encodebytes(certificate.get_pem_cer(
            certificate.cer_file)).decode('UTF-8')
        key_pem = base64.encodebytes(certificate.get_pem_key(
            certificate.key_file,
            certificate.password)).decode('UTF-8')
        data = {
            'rfc': xml.Emisor.get('Rfc'),
            'b64Cer': cer_pem,
            'b64Key': key_pem,
            'password': certificate.password,
            'uuid': tfd_node.get('UUID'),
        }
        response_json = self._l10n_mx_edi_sw_post(
            url, headers, payload=json.dumps(data).encode('UTF-8'))
        code = response_json.get('message')
        msg = response_json.get('messageDetail')
        if response_json['status'] == 'success':
            self.cfdi_fecha_cancelacion = time.strftime(
                '%Y-%m-%d %H:%M:%S')
            self.message_post(
                body=_('\n- El proceso de cancelación se ha completado correctamente.'))
        else:
            self.message_post(body=_('Mensaje %s\nCode: %s') % (msg, code))

    def check_required_values(self):
        self.ensure_one()
        msg = []
        if not self.company_id.certificate_id:
            msg.append('No tienes definido certificado para esta compañia !')
        if not self.uso_cfdi_id.name:
            msg.append('La factura no tiene UsoCFDI !')
        if not self.met_pago_id.name:
            msg.append('La factura no tiene Método de Pago !')
        if not self.forma_pago_id.name:
            msg.append('La factura no tiene Forma de Pago !')
        if not self.company_emitter_id.partner_id.res_fiscal_regime_id:
            msg.append('La Empresa no tiene Regimen Fiscal !')
        for line in self.invoice_line_ids.filtered(
                lambda l: not l.product_id.claveserv_id):
            msg.append('Producto %s no tiene ClaveServ SAT !' % line.product_id.name)  # noqa
        if msg:
            msgs = ''
            for item in msg:
                msgs += '<li>' + item + '</li>'
            self.message_post(body=_('<ul>' + msgs + '</ul>'))
            return False
        return True

    def create_cfdi(self):
        all_paths = tools.config["addons_path"].split(",")
        path_cadena = False
        for my_path in all_paths:
            if os.path.isdir(os.path.join(my_path, 'l10n_mx_facturae_40', 'SAT')):
                path_cadena = os.path.join(
                    my_path, 'l10n_mx_facturae_40', 'SAT', 'cadenaoriginal_4.xslt')
                continue
        type_invoice = 'I'
        for invoice in self.filtered(lambda i: i.journal_id.fiscal and i.check_required_values()):
            certificate_id = invoice.company_id.certificate_id
            invoice_datetime = invoice.date_invoice_tz_33.strftime(
                '%Y-%m-%dT%H:%M:%S')
            if invoice.move_type == 'out_invoice':
                type_invoice = 'I'
            if invoice.move_type == 'out_refund':
                type_invoice = 'E'

            lines = []
            tax_trasladados = False
            tax_retencion = False
            total_tax_tras = total_tax_ret = 0
            tax_traslados_list = []
            tax_ret_list = []
            drop_tax = False
            total_discount = subtotal = discount = total_tax = 0
            number = self._l10n_mx_edi_get_serie_and_folio(invoice)
            moneda = 'MXN'
            tipo_cambio = '1'
            if invoice.currency_id and invoice.currency_id.name:
                moneda = invoice.currency_id.name
            if str(moneda) != 'MXN':
                tipo_cambio = str("%.2f" % (
                    1 / invoice.currency_id.rate))
            try: 
                invoice_tax = invoice.tax_line_ids.filtered(lambda x: x.amount)
            except:
                invoice_tax = False

            if invoice_tax:
                cve_impuesto = "02"
            else:
                cve_impuesto = "01"

            for line in invoice.invoice_line_ids:

                if invoice.carta_porte:
                    clv_prodserv = "78101500"
                else:
                    clv_prodserv = line.claveserv_id.name
        
                discount = 0
                drop_tax = True
                nom_uom = line.product_uom_id.name or 'pieza'

                line_subtotal = round(line.price_subtotal * 100 / (
                    100 - line.discount), 2)
                if line.discount:
                    discount = round(line.discount / 100 * line_subtotal, 2)
                line_dic = {
                    'cantidad': "%.2f" % (line.quantity),
                    'unidad': nom_uom,
                    'noIdentificacion': str(line.product_id.default_code),
                    'descripcion': str(conv_ascii(line.name)),
                    'valorUnitario': round(line_subtotal/line.quantity, 2),
                    'importe': "%.2f" % (line_subtotal),
                    'descuento': False,
                    'ClaveUnidad': line.product_uom_id.claveuni_id.clave or 'EA',
                    'ClaveProdServ': clv_prodserv,
                    'ObjetoImp': cve_impuesto,
                    'Exportacion' : "01" ,
                    'Impuestos': {
                        'Traslados': [],
                        'Retenciones': [],
                    },
                }
                total_discount += discount
                subtotal += line_subtotal
                for tax in line.tax_ids:
                    total_tax += 1
                    drop_tax = False
                    add = True
                    if tax.amount >= 0:
                        tax_trasladados = True
                        line_dic['Impuestos']['Traslados'].append({
                            'impuesto': tax.code_sat,
                            'tasaocuota': "%.6f" % (tax.amount/100),
                            'tipofactor': 'Tasa',
                            'importe': "%.2f" % (
                                line.price_subtotal * (tax.amount / 100)),
                            'base': "%.2f" % (line.price_subtotal),
                        })
                        if not tax_traslados_list:
                            tax_traslados_list.append({
                                'impuesto': tax.code_sat,
                                'tasaocuota': "%.6f" % (tax.amount/100),
                                'importe': "%.2f" % (line.price_subtotal * (
                                    tax.amount / 100)),
                                'tipofactor': 'Tasa',
                                'base': "%.2f" % (line.price_subtotal),
                            })
                        else:
                            for t in tax_traslados_list:
                                if (
                                    t['impuesto'] == tax.code_sat and
                                    "%.6f" % float(t[
                                        'tasaocuota']) == "%.6f" %
                                        float(tax.amount / 100)):
                                    add = False
                            if add:
                                tax_traslados_list.append({
                                    'impuesto': tax.code_sat,
                                    'tasaocuota': "%.6f" % (tax.amount/100),
                                    'importe': "%.2f" % (
                                        line.price_subtotal * (
                                            tax.amount / 100)),
                                    'tipofactor': 'Tasa',
                                    'base': "%.2f" % (line.price_subtotal),
                                })
                            else:
                                for t in tax_traslados_list:
                                    if t['impuesto'] == tax.code_sat and "%.6f" % float(
                                            t['tasaocuota']) == "%.6f" % float(
                                                tax.amount/100):
                                        before = t['importe']
                                        t['importe'] = "%.2f" % (
                                            float(before) +
                                            line.price_subtotal *
                                            (tax.amount/100))
                                        before_b = t['base']
                                        t['base'] = "%.2f" % (
                                            float(before_b) +
                                            line.price_subtotal )
                        total_tax_tras += round(line.price_subtotal * (
                            tax.amount/100), 2)
                    if tax.amount < 0:
                        tax_retencion = True
                        line_dic['Impuestos']['Retenciones'].append({
                            'impuesto': tax.code_sat,
                            'tasaocuota': "%.6f" % (abs(tax.amount/100)),
                            'tipofactor': 'Tasa',
                            'importe': "%.2f" % (abs(line.price_subtotal * (
                                tax.amount/100))),
                            'base': "%.2f" % (line.price_subtotal),
                        })
                        if not tax_ret_list:
                            tax_ret_list.append({
                                'impuesto': tax.code_sat,
                                'tasaocuota': "%.6f" % (abs(tax.amount/100)),
                                'importe': "%.2f" % (abs(
                                    line.price_subtotal * (tax.amount/100))),
                                'tipofactor': 'Tasa',
                            })
                        else:
                            for t in tax_ret_list:
                                if t['impuesto'] == tax.code_sat and "%.6f" % float(t['tasaocuota']) == "%.6f" % float(tax.amount/100):
                                    add = False
                            if add:
                                tax_ret_list.append({
                                    'impuesto': tax.code_sat,
                                    'tasaocuota': "%.6f" % (abs(
                                        tax.amount / 100)),
                                    'importe': "%.2f" % (abs(
                                        line.price_subtotal *
                                        (tax.amount/100))),
                                    'tipofactor': 'Tasa',
                                })
                            else:
                                for t in tax_ret_list:
                                    if t['impuesto'] == tax.code_sat and "%.6f" % float(t['tasaocuota']) == "%.6f" % float((abs(tax.amount))/100):
                                        before = t['importe']
                                        t['importe'] = "%.2f" % (
                                            float(before) +
                                            line.price_subtotal*(
                                                tax.amount/100))
                        total_tax_ret += round((abs(
                            line.price_subtotal*(tax.amount/100))),2)
                
                if drop_tax:
                    line_dic.pop('Impuestos')
                lines.append(line_dic)

            if invoice.partner_id._get_vat_partner() == "XAXX010101000" and invoice.partner_id.name == 'PÚBLICO EN GENERAL':
                type_days = (invoice.invoice_date_due - invoice.invoice_date)  / timedelta(days=1)
                meses = diff_month(invoice.invoice_date_due , invoice.invoice_date)
                if type_days < 7.0:
                    c_periodicidad = "01"
                if type_days >= 7 and type_days <= 15:
                    c_periodicidad = "02"
                if meses == 1:
                    c_periodicidad = "03"
                if meses > 1:
                    c_periodicidad = "03"
                c_meses = str(invoice.invoice_date_due)[5:7]
                c_anio = invoice.invoice_date_due.year
            else:
                c_periodicidad = False
                c_meses = False
                c_anio = False

            data = {
                'Atributos': {
                    'serie': number['serie_number'] or 'NA',
                    'folio': number['folio_number'] or 'NA',
                    'fecha': invoice_datetime,
                    'sello': '',
                    'formaDePago': invoice.forma_pago_id.name,
                    'noCertificado': certificate_id.serial_number,
                    'certificado': (
                        certificate_id.sudo().get_data()[0].decode()),
                    'condicionesDePago': '',
                    'subTotal': "%.2f" % (subtotal),
                    'descuento': False,
                    'TipoCambio': tipo_cambio,
                    'Moneda': moneda,
                    'total': "%.2f" % (
                        subtotal - total_discount +
                        total_tax_tras -
                        total_tax_ret),
                    'tipoDeComprobante': type_invoice,
                    'metodoDePago': invoice.met_pago_id.name,
                    'LugarExpedicion': invoice.address_issued_id.zip,
                    'Exportacion':"01",
                },
                'Global': {
                    'Periodicidad': c_periodicidad or '',
                    'Meses' : c_meses or '',
                    'Anio': c_anio or '',
                },
                'Emisor': {
                    'rfc': invoice.company_emitter_id.partner_id.vat or '',
                    'nombre': invoice.company_emitter_id.name,
                    'regimenFiscal': invoice.company_emitter_id.partner_id.res_fiscal_regime_id.code,
                    'RegimenFiscalEmisor': invoice.company_emitter_id.partner_id.res_fiscal_regime_id.code,
                },
                'Receptor': {
                    'rfc': invoice.partner_id._get_vat_partner(),
                    'nombre': invoice.partner_id.name,
                    'UsoCFDI': invoice.uso_cfdi_id.name,
                    'zip': invoice.partner_id.zip,
                    'RegimenFiscalReceptor': invoice.partner_id.res_fiscal_regime_id.code,
                },
                'Conceptos': lines,
                'Impuestos': {},
                'CartaPorte': {},
            }
        
            if total_tax > 0:
                if tax_traslados_list:
                    data['Impuestos'] = {
                        'totalImpuestosTrasladados': "%.2f" % (total_tax_tras)}
                    data['Impuestos']['Traslados'] = tax_traslados_list
                if tax_ret_list:
                    data['Impuestos'].update({
                        'totalImpuestosRetenidos': "%.2f" % (total_tax_ret)})
                    sum_rt_001 = 0
                    sum_rt_002 = 0
                    sum_rt_003 = 0
                    list_ret = []
                    for rt in tax_ret_list:
                        if rt['impuesto'] == '001':
                            sum_rt_001 += float(rt['importe'])
                        if rt['impuesto'] == '002':
                            sum_rt_002 += float(rt['importe'])
                        if rt['impuesto'] == '003':
                            sum_rt_003 += float(rt['importe'])
                    if sum_rt_001:
                        list_ret.append({'impuesto': '001', 'importe': sum_rt_001})
                    if sum_rt_002:
                        list_ret.append({'impuesto': '002', 'importe': sum_rt_002})
                    if sum_rt_003:
                        list_ret.append({'impuesto': '003', 'importe': sum_rt_003})
                    data['Impuestos'].update({
                        'Retenciones': list_ret})
            else:
                data.pop('Impuestos')
            if invoice.invoice_rel_ids:
                uuids = []
                for invoice_rel_id in invoice.invoice_rel_ids:
                    uuids.append(invoice_rel_id.cfdi_folio_fiscal)
                data['CfdiRelacionados'] = {
                    'tiporelacion': invoice.type_invoice_rel,
                    'uuids': uuids,
                }

            # self.validate_data(data,cer, key, pass_key)
            env = Environment(
                loader=FileSystemLoader(
                    os.path.join(
                        os.path.dirname(os.path.abspath(
                            __file__)), '../template',),),
                undefined=StrictUndefined, autoescape=True,
            )

            
            if invoice.carta_porte:
                order = self.env['sale.order'].search([('name', '=', invoice.invoice_origin)])
                picking = order.picking_ids[0]
                
                if not picking.l10n_mx_cp_transport_type or picking.l10n_mx_cp_transport_type == "00":
                    raise UserError("Se debe seleccionar un tipo de transporte para poder generar el complemento de carta porte")
                else:
                    if picking.l10n_mx_cp_distance == 0:
                        raise UserError("La distancia debe ser mayor que 0")
                    if picking.l10n_mx_cp_vehicle_id:
                        if not picking.l10n_mx_cp_vehicle_id.vehicle_licence:
                            raise UserError("Debes añadir en el vehículo su matricula")
                        if not picking.l10n_mx_cp_vehicle_id.vehicle_model:
                            raise UserError("Debes añadir en el vehículo su año")
                        if not picking.l10n_mx_cp_vehicle_id.vehicle_config:
                            raise UserError("Debes añadir en el vehículo su tipo de configuración")
                        if not picking.l10n_mx_cp_vehicle_id.transport_perm_sct:
                            raise UserError("Debes añadir en el vehículo su tipo de tipo de permiso")
                        if not picking.l10n_mx_cp_vehicle_id.name:
                            raise UserError("Debes añadir en el vehículo su nombre")
                        if not picking.l10n_mx_cp_vehicle_id.transport_insurer:
                            raise UserError("Debes añadir en el vehículo su compañia de seguros")
                        if not picking.l10n_mx_cp_vehicle_id.transport_insurance_policy:
                            raise UserError("Debes añadir en el vehículo su número de poliza")
                        if not picking.l10n_mx_cp_vehicle_id.figure_ids:
                            raise UserError("El vehíulo debe tener al menos una figura")
                    else:
                        raise UserError("Debes seleccionar un vehículo para enviar")

                    tz = pytz.timezone('America/Mexico_City')
                    ct = datetime.now(tz=tz)
                    date_fmt = '%Y-%m-%dT%H:%M:%S'
                    
                    data['CartaPorte'].update({
                        'TotalDistRec' : picking.l10n_mx_cp_distance,
                        'Origen': {
                                    'IDUbicacion': 'OR' + str(picking.location_id.id),
                                    'FechaHoraSalidaLlegada': ct.strftime(date_fmt),
                                    'RFCRemitenteDestinatario': invoice.company_emitter_id.partner_id.vat.replace('&', '&amp;') or '',
                                    'Domicilio': {
                                        'Calle': picking.company_id.partner_id.street,
                                        'CodigoPostal': picking.company_id.partner_id.zip,
                                        'Localidad': picking.company_id.partner_id.l10n_mx_cp_code_localidad,
                                        'Municipio': picking.company_id.partner_id.l10n_mx_cp_code_municipio,
                                        'Estado': picking.company_id.partner_id.state_id.code,
                                        'Pais':picking.company_id.partner_id.country_id.l10n_mx_cp_code,
                                        }
                                    },
                        'Destino': {
                                    'IDUbicacion': 'DE' + str(picking.location_dest_id.id),
                                    'FechaHoraSalidaLlegada': picking.scheduled_date.strftime(date_fmt),
                                    'RFCRemitenteDestinatario': invoice.partner_id.vat.replace('&', '&amp;') or '',
                                    'Domicilio': {
                                        'Calle': invoice.partner_id.street,
                                        'CodigoPostal': invoice.partner_id.zip,
                                        'Localidad': invoice.partner_id.l10n_mx_cp_code_localidad,
                                        'Municipio': invoice.partner_id.l10n_mx_cp_code_municipio,
                                        'Estado': invoice.partner_id.state_id.code,
                                        'Pais':invoice.partner_id.country_id.l10n_mx_cp_code,
                                        }
                                    },
                        'Autotransporte': {
                                        'NumPermisoSCT': picking.l10n_mx_cp_vehicle_id.name,
                                        'PermSCT': picking.l10n_mx_cp_vehicle_id.transport_perm_sct,
                                        'IdentificacionVehicular': {
                                            'AnioModeloVM': picking.l10n_mx_cp_vehicle_id.vehicle_model,
                                            'ConfigVehicular':picking.l10n_mx_cp_vehicle_id.vehicle_config,
                                            'PlacaVM': picking.l10n_mx_cp_vehicle_id.vehicle_licence,
                                        },
                                        'Seguros': {
                                            'AseguraRespCivil': picking.l10n_mx_cp_vehicle_id.transport_insurer,
                                            'PolizaRespCivil': picking.l10n_mx_cp_vehicle_id.transport_insurance_policy,
                                        }
                                    },
                        'FiguraTransporte': {
                                    'RFCFigura': picking.l10n_mx_cp_vehicle_id.figure_ids.operator_id.vat,
                                    'NumLicencia': picking.l10n_mx_cp_vehicle_id.figure_ids.operator_id.l10n_mx_cp_operator_licence,
                                    'TipoFigura' : "01"
                                    },
                        'Mercancias': {
                                    'UnidadPeso': "XBX",
                                    'NumTotalMercancias': len(invoice.invoice_line_ids.filtered(lambda p: p.product_id.type != "service")),
                                    'PesoBrutoTotal': picking.weight
                                    }
                        })
                    
                    def get_concep_carta(invoice):
                        lines_carta = []
                        for line in invoice.invoice_line_ids.filtered(lambda p: p.product_id.type != "service"):   
                            line_dic_carta = {
                                'BienesTransp': line.claveserv_id.name,
                                'MaterialPeligroso': line.product_id.material_peligroso,
                                'ClaveUnidad': line.product_uom_id.claveuni_id.clave,
                                'Cantidad': line.quantity,
                                'Descripcion': line.name,
                                'PesoEnKg': line.product_id.weight
                            }
                            lines_carta.append(line_dic_carta)
                        return lines_carta
                
                    data['ConceptosCarta'] = get_concep_carta(invoice)
            template = env.get_template('cfdi.jinja')
            xml = template.render(data=data).encode('utf-8')
            cadena = self.generate_cadena_original(
                xml, {'path_cadena': path_cadena})
            
            sello = certificate_id.get_sello(cadena)
            tree = objectify.fromstring(xml)
            tree.attrib['Sello'] = sello.decode("utf-8") 
            xml = etree.tostring(
                tree, pretty_print=True,
                xml_declaration=True, encoding='UTF-8')
            fname = '%s_%s.xml' % (invoice.company_emitter_id.partner_id.vat,
                                invoice.name)
            ctx = self.env.context.copy()
            ctx.pop('default_type', False)
            attachment = self.env['ir.attachment'].with_context(ctx).create({
                'name': fname,
                'datas': base64.b64encode(xml),
                'res_model': 'account.move',
                'res_id': invoice.id,
                'mimetype': 'application/xml',
                'type': 'binary',
            })
            invoice.message_post(
                body=_('CFDI generated'),
                attachment_ids=[attachment.id])
            invoice.cfdi_name = fname
            return True
        for invoice in self:
            invoice.message_post(body=_('Debe estar activado el campo Diario SAT en el diario de la factura'))
        return True

    def _create_original_str(self):
        cfdi_folio_fiscal = self.cfdi_folio_fiscal or ''
        cfdi_fecha_timbrado = self.cfdi_fecha_timbrado or ''
        sello = self.cfdi_sello or ''
        cfdi_no_certificado = self.cfdi_no_certificado or ''
        original_string = '||1.1|' + cfdi_folio_fiscal + '|' + str(
            cfdi_fecha_timbrado).replace(' ', 'T') + '|' + sello + '|' + cfdi_no_certificado + '||'
        return original_string

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        res = super()._onchange_partner_id()
        if self.move_type in ('in_invoice', 'in_refund'
                              ) or not self.partner_id.commercial_partner_id:
            return res
        self.met_pago_id = self.partner_id.commercial_partner_id.met_pago_cfdi_id
        self.forma_pago_id = self.partner_id.commercial_partner_id.forma_pago_cfdi_id
        self.uso_cfdi_id = self.partner_id.uso_cfdi_id.id or False
        return res

    @classmethod
    def validate_data(self, data, cer, key, pwd):
        '''
        This method will be used to validate correct input.
        @param data: python dictionary with invoide data.
        '''
        if cer and key and pwd != '':
            data['Atributos']['certificado'] = cer
            data['Atributos']['noCertificado'] = self.get_noCertificado(cer)

    @classmethod
    def generate_cadena_original(self, xml, context=None):
        xlst_file = tools.file_open(context.get('path_cadena', '')).name
        dom = etree.fromstring(xml)
        xslt = etree.parse(xlst_file)
        transform = etree.XSLT(xslt)
        return str(transform(dom))

    @classmethod
    def base64_to_tempfile(self, b64_str=None, suffix=None, prefix=None):
        """ Convert strings in base64 to a temp file
        @param b64_str : Text in Base_64 format for add in the file
        @param suffix : Sufix of the file
        @param prefix : Name of file in TempFile
        """
        (fileno, file_name) = tempfile.mkstemp(suffix, prefix)
        f_read = open(file_name, 'wb')
        f_read.write(base64.b64decode(b64_str))
        f_read.close()
        os.close(fileno)
        return file_name

    @api.model
    def _get_stamp_data(self, cfdi):
        self.ensure_one()
        if not hasattr(cfdi, 'Complemento'):
            return None
        attribute = 'tfd:TimbreFiscalDigital[1]'
        namespace = {'tfd': 'http://www.sat.gob.mx/TimbreFiscalDigital'}
        node = cfdi.Complemento.xpath(attribute, namespaces=namespace)
        return node[0] if node else None

    def button_draft(self):
        records = self
        for inv in self.filtered('journal_id.fiscal'):
            att = inv.retrive_attachment()
            if not att:
                continue
            status = inv.valida_xml(att.datas).get('acuse')
            if status and status.Estado == 'Cancelado':
                continue
            if status and status.Estado != 'Cancelado':
                inv.action_cancel_cfdi()
            status = inv.valida_xml(att.datas).get('acuse')
            inv.sat_status = status and status.Estado or ''
            if inv.sat_status != 'Cancelado':
                records -= inv
                inv.message_post(body=_(
                    'This invoice is not cancelled in the SAT system'))
        return super(AccountMove, records).button_draft()

    def action_invoice_validate(self):
        records = self
        for inv in self.filtered('journal_id.fiscal'):
            att = inv.retrive_attachment()
            if not att:
                continue
            status = inv.valida_xml(att.datas).get('acuse')
            if status and status.Estado:
                
                inv.write({'sat_status': status.Estado})
            else:
                inv.message_post(body=_(
                    'Revisa tu conexión a internet'))


    
    def valida_xml(self, xml_file):
        url = 'https://consultaqr.facturaelectronica.sat.gob.mx/ConsultaCFDIService.svc?wsdl'  # noqa
        try:
            client = Client(url)
            (fileno, fname) = tempfile.mkstemp(".xml", "invoice_tmp")
            f = open(fname, 'wb')
            f.write(base64.b64decode(xml_file or ''))
            f.close()
            os.close(fileno)
            fo = open(fname, "r")
            tree = objectify.fromstring(fo.read().encode())
            tfd = self._get_stamp_data(tree)
            rfc_emisor = tree.Emisor.get('Rfc', '').replace('&', '&amp;amp;')
            rfc_receptor = tree.Receptor.get('Rfc', '').replace(
                '&', '&amp;amp;')
            ffiscal = tfd.get('UUID')
            total = tree.get('Total')
            acuse = """"?re=%s&rr=%s&tt=%f&id=%s""" % (
                rfc_emisor, rfc_receptor, float(total), ffiscal)
            res = client.service.Consulta(acuse)
            dict_data = {}
            return {'acuse': res, 'comprobante': dict_data}
        except:
            try:
                dict_data = {}
            except:
                dict_data = {}
            return {'acuse': False, 'comprobante': dict_data}

    @api.model
    def _get_time_zone_33(self):
        res_users_obj = self.env['res.users']
        userstz = res_users_obj.browse(self._uid).partner_id.tz
        total = 0
        if userstz:
            hours = timezone(userstz)
            fmt = '%Y-%m-%d %H:%M:%S %Z%z'
            now = datetime.datetime.now()
            loc_dt = hours.localize(datetime.datetime(
                now.year, now.month, now.day, now.hour, now.minute,
                now.second))
            timezone_loc = (loc_dt.strftime(fmt))
            diff_timezone_original = timezone_loc[-5:-2]
            timezone_original = int(diff_timezone_original)
            times = str(datetime.datetime.now(pytz.timezone(userstz)))
            times = times[-6:-3]
            timezone_present = int(times)*-1
            total = timezone_original + ((
                timezone_present + timezone_original)*-1)
        return total

    @api.model
    def assigned_datetime_33(self, values):
        res = {}
        if values.get(
            'invoice_date', False) and not values.get(
                'invoice_datetime_33', False):
            res['invoice_datetime_33'] = fields.Datetime.from_string(
                fields.Datetime.now()).strftime('%Y-%m-%d %H:%M:%S')
            res['invoice_date'] = values['invoice_date']
        if values.get('invoice_datetime_33', False) and not values.get(
                'invoice_date', False):
            invoice_date = values['invoice_datetime_33'].date().strftime(
                '%Y-%m-%d')
            res['invoice_date'] = invoice_date
            res['invoice_datetime_33'] = values['invoice_datetime_33']

        if 'invoice_datetime_33' in values and 'invoice_date' in values and values[  # noqa
                'invoice_datetime_33'] and values['invoice_date']:
            invoice_date = values['invoice_datetime_33'].date().strftime(
                '%Y-%m-%d')
            if invoice_date != values['invoice_date'].strftime('%Y-%m-%d'):
                invoice_date = fields.Datetime.context_timestamp(
                    self, values['invoice_datetime_33'])
                res['invoice_date'] = invoice_date
                res['invoice_datetime_33'] = values['invoice_datetime_33']

        if not values.get('invoice_datetime_33', False) and not values.get('invoice_date', False):
            res['invoice_date'] = fields.Date.context_today(self)
            res['invoice_datetime_33'] = fields.Datetime.now()

        return res

    def action_post(self):
        for inv in self.filtered(lambda i: i.move_type in ('out_invoice', 'out_refund')):
            vals_date = inv.assigned_datetime_33({
                'invoice_datetime_33': inv.invoice_datetime_33,
                'invoice_date': inv.invoice_date
            })
            inv.write(vals_date)
        res = super(AccountMove, self).action_post()
        self.create_cfdi()
        return res
    
    def _get_report_values(self, docids, data=None):
        invoice_obj = self.env['account.invoice']
        invoice = invoice_obj.browse(docids)
        return {
            "doc_ids": docids,
            "doc_model": 'account.invoice',
            "docs": invoice,
            'time': time,
            'int': int,
            'datetime': datetime,
            'get_invoice_line': self.get_invoice_line,
            'get_local_tax': self.get_local_tax,
            'get_taxes': self.get_taxes,
            'get_cfdi_folio': self.get_cfdi_folio,
            'get_uso_cfdi': self.get_uso_cfdi,
            'get_fecha_emision': self.get_fecha_emision,
            'get_tipo_comprobante': self.get_tipo_comprobante,
            'get_regimen': self.get_regimen,
            'get_cantidad_letra': self.get_cantidad_letra,
            'get_subtotal': self.get_subtotal,
            'get_total': self.get_total,
        }

    def get_invoice_line(self, invoice):
        line = []
        lines = []
        # Para cada linea de factura
        for invoice_line in invoice.invoice_line_ids:
            line.append(invoice_line.product_id.default_code)
            line.append(invoice_line.name)
            line.append(invoice_line.quantity)
            line.append(invoice_line.uom_id.name)
            line.append('{:20,.2f}'.format(invoice_line.price_unit))
            line.append('{:20,.2f}'.format(invoice_line.discount))
            line.append('{:20,.2f}'.format(invoice_line.price_subtotal))
            line.append(invoice_line.claveserv_id.name or '01010101')
            line.append(invoice_line.uom_id.claveuni_id.clave or 'H87')
            taxes_list = []
            for tax in invoice_line.invoice_line_tax_ids:
                taxes_list.append({
                    'name': tax.name,
                    'amount': '%.2f' % (
                        invoice_line.price_subtotal * (tax.amount / 100)),
                })
            line.append(taxes_list)
            lines.append(line)
            line = []
        return lines

    def get_dic(self):
        attach_obj = self.env['ir.attachment']
        attach_row = self.env['ir.attachment'].search([
            ('name', '=', self.cfdi_name),
            ('res_model', '=', 'account.move'),
            ('res_id', '=', self.id)], limit=1)
        dic = {}
        for atta in attach_row:
            dict_data = dict(xmltodict.parse(base64.b64decode(
                atta.datas)).get('cfdi:Comprobante', {}))
            dic = dict_data
        return dic

    def get_rfc_provider(self):
        tfd = self.get_dic()
        rfc_provider = tfd.get('cfdi:Complemento', {}).get(
            'tfd:TimbreFiscalDigital', {}).get('@RfcProvCertif', '')
        return rfc_provider or " "

    def get_fecha_emision(self):
        tfd = self.get_dic()
        fecha_emision = tfd.get('@Fecha', '')
        return fecha_emision or " "
    
    def get_cfdi_sello(self):
        tfd = self.get_dic()
        sello = tfd.get('@Sello', '')
        return sello or " "

    def get_fecha_certificacion(self):
        tfd = self.get_dic()
        fecha_certificacion = tfd.get('cfdi:Complemento', {}).get(
            'tfd:TimbreFiscalDigital', {}).get('@FechaTimbrado', '')
        return fecha_certificacion or " "

    def get_cer_sat(self):
        tfd = self.get_dic()
        sello_sat = tfd.get('cfdi:Complemento', {}).get(
            'tfd:TimbreFiscalDigital', {}).get('@NoCertificadoSAT', '')
        return sello_sat or " "

    
    def get_cfdi_folio(self):
        if not self.sign:
            return ""
        try:
            tree = self.cfdi_etree()
            tfd = self._get_stamp_data(tree)
            return tfd.get('SelloSAT', '')
        except Exception as e:
            return "SIN SELLO"

    def get_taxes(self, invoice):
        taxes_list = []
        for tax in invoice.tax_line_ids:
            taxes_list.append({
                'name': tax.name,
                'amount': '{:20,.2f}'.format(tax.amount)
            })
        return taxes_list

    def get_uso_cfdi(self, invoice):
        if invoice.sign:
            try:
                tree = invoice.cfdi_etree()
                uso_cfdi = tree.Receptor.get('UsoCFDI')
                # Buscamos el uso en los catálogos
                res_uso_cfdi_row = self.env['res.uso.cfdi'].search([
                    ('name', '=', uso_cfdi)])
                uso_cfdi_text = uso_cfdi + " - " + res_uso_cfdi_row.description or ""
                return uso_cfdi_text
            except:
                return "SIN USO CFDI"
        else:
            return "SIN USO CFDI"

    def _get_time_zone(self):
        res_users_obj = self.env['res.users']
        userstz = res_users_obj.browse(self._uid).tz
        a = 0
        if userstz:
            hours = timezone(userstz)
            fmt = '%Y-%m-%d %H:%M:%S %Z%z'
            now = datetime.now()
            loc_dt = hours.localize(datetime(now.year, now.month, now.day,
                                             now.hour, now.minute, now.second))
            timezone_loc = (loc_dt.strftime(fmt))
            diff_timezone_original = timezone_loc[-5:-2]
            timezone_original = int(diff_timezone_original)
            s = str(datetime.now(timezone(userstz)))
            s = s[-6:-3]
            timezone_present = int(s)*-1
            a = timezone_original + ((
                timezone_present + timezone_original)*-1)
        return a

    def get_tipo_comprobante(self, invoice):
        if invoice.sign:
            try:
                tree = invoice.cfdi_etree()
                tipo = tree.get('TipoDeComprobante', '')
                if tipo == 'I':
                    tipo += " - Ingreso"
                if tipo == 'E':
                    tipo += " - Egreso"
                return tipo
            except:
                return "SIN TIPO"
        else:
            return ""

    def get_regimen(self, invoice):
        reg = invoice.company_emitter_id.partner_id.res_fiscal_regime_id  # noqa
        return reg.name

    def get_cantidad_letra(self):
        for invoice in self:
            currency = invoice.currency_id.name.upper()
            # M.N. = Moneda Nacional (National Currency)
            # M.E. = Moneda Extranjera (Foreign Currency)
            currency_type = 'M.N' if currency == 'MXN' else 'M.E.'
            # Split integer and decimal part
            amount_i, amount_d = divmod(invoice.amount_total, 1)
            amount_d = round(amount_d, 2)
            amount_d = int(round(amount_d * 100, 2))
            words = invoice.currency_id.with_context(
                lang=invoice.partner_id.lang or 'es_ES').amount_to_text(
                    amount_i).upper()
            return '%(words)s %(amount_d)02d/100 %(curr_t)s' % dict(
                words=words, amount_d=amount_d, curr_t=currency_type)

    def get_subtotal(self, invoice):
        return '{:20,.2f}'.format(invoice.amount_untaxed)

    def get_total(self, invoice):
        return '{:20,.2f}'.format(invoice.amount_total)

    def get_local_tax(self):
        local_taxes = []
        if self.dic:
            local_taxes = self.dic.get('cfdi:Complemento', {}).get(
                'implocal:ImpuestosLocales', {}).get('implocal:RetencionesLocales', [])
        taxes_list = []
        for tax in local_taxes:
            taxes_list.append({'importe': tax.get('@Importe', 0.0), 'name': tax.get(
                '@ImpLocRetenido', ''), 'tasa': tax.get('@TasadeRetencion', '')})
        return taxes_list or []