# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    def _prepare_invoice_line(self,  **optional_values):
        res = super()._prepare_invoice_line()
        res.update({
            'claveserv_id': self.product_id.claveserv_id and
                            self.product_id.claveserv_id.id or
                            self.product_id.product_tmpl_id.claveserv_id and
                            self.product_id.product_tmpl_id.claveserv_id.id or
                            self.product_id.categ_id.claveserv_id and
                            self.product_id.categ_id.claveserv_id.id or False
        })
        return res