# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models
from odoo.exceptions import UserError

class IrAttachment(models.Model):

    _inherit = 'ir.attachment'

    def unlink(self):
        invoice = self.env['account.move']
        for record in self.filtered(lambda record: record.res_model == invoice._name and '.xml' in record.name):
            if invoice.browse(record.res_id).sign:
                raise UserError('No puedes eliminar un adjunto si la factura fue timbrada')
        return super().unlink()
