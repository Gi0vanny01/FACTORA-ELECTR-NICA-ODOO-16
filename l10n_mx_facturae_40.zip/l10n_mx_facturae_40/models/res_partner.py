# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    uso_cfdi_id = fields.Many2one('res.uso.cfdi')
    met_pago_cfdi_id = fields.Many2one(
        'res.met.pago',
        string="Payment Method",
        help='This payment method will be used by default in the related '
        'documents (invoices, payments, and bank statements).')
    forma_pago_cfdi_id = fields.Many2one(
        'res.forma.pago',
        string="Payment Way",
        help='This payment method will be used by default in the related '
        'documents (invoices, payments, and bank statements).')
    res_fiscal_regime_id = fields.Many2one(
       comodel_name='res.fiscal.regime', string='Fiscal regime')

    def _get_vat_partner(self):
        self.ensure_one()
        if self.country_id and self.country_id != self.env.ref('base.mx'):
            return 'XEXX010101000'
        return self.vat or ''