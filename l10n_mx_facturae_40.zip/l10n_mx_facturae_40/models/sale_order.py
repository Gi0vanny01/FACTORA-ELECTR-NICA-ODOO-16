# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    forma_pago_id = fields.Many2one('res.forma.pago', 'Forma de pago')
    met_pago_id = fields.Many2one('res.met.pago', 'Metodo de pago')

    def _prepare_invoice(self):
        res = super()._prepare_invoice()
        res.update({
            'uso_cfdi_id': self.partner_id.uso_cfdi_id.id if self.partner_id and self.partner_id.uso_cfdi_id else False,
            'forma_pago_id': self.forma_pago_id.id if self.forma_pago_id else False,
            'met_pago_id': self.met_pago_id.id if self.met_pago_id else False,
        })
        return res