# -*- coding: utf-8 -*-
# Copyright 2023 - QUADIT, SA DE CV (https://www.quadit.mx)
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResFormaPago(models.Model):
    """Object use to save the catalog to payment ways"""
    _name = 'res.forma.pago'
    _description = 'Forma de pago'
    _sql_constraints = [('name_unique', 'UNIQUE (name)', 'El codigo debe ser unico')]

    name = fields.Char(size=3, required=True)
    description = fields.Char(size=256)
    bancarizado = fields.Boolean()

    @api.depends('name', 'description')
    def name_get(self):
        result = []
        for pay in self:
            name = pay.name + ' ' + pay.description
            result.append((pay.id, name))
        return result